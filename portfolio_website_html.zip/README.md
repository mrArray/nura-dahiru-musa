# Nura Dahiru Musa - Portfolio Website

A modern, responsive portfolio website for Nura Dahiru Musa, featuring an ongoing research papers section and professional experience showcase.

## Features

- Responsive design for all devices
- Modern and professional UI with light/dark mode toggle
- Dedicated ongoing research papers section
- Interactive elements and smooth animations
- Contact form for easy communication
- Comprehensive skills and experience showcase

## Setup Instructions for GitHub Pages

1. **Fork or Clone the Repository**
   - Fork this repository to your GitHub account, or
   - Clone it locally: `git clone https://github.com/yourusername/portfolio.git`

2. **Modify Content (Optional)**
   - Update personal information in the HTML files
   - Replace placeholder profile image with your own
   - Modify research papers and other sections as needed

3. **Deploy to GitHub Pages**
   - Go to your repository settings
   - Scroll down to the GitHub Pages section
   - Select the main branch as the source
   - Click Save

4. **Access Your Website**
   - Your website will be available at `https://yourusername.github.io/portfolio/`
   - It may take a few minutes for changes to propagate

## Local Development

1. **Clone the Repository**
   ```
   git clone https://github.com/yourusername/portfolio.git
   cd portfolio
   ```

2. **Open in Browser**
   - Simply open the `index.html` file in your browser
   - For a local server, you can use:
     - Python: `python -m http.server`
     - Node.js: `npx serve`

3. **Make Changes**
   - Edit HTML, CSS, and JavaScript files as needed
   - Refresh your browser to see changes

## File Structure

```
portfolio/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # Main stylesheet
├── js/
│   └── main.js         # JavaScript functionality
└── README.md           # This documentation
```

## Customization

- **Colors**: Edit CSS variables in the `:root` section of style.css
- **Content**: Update text in index.html
- **Images**: Replace placeholder profile image
- **Research Papers**: Add or modify papers in the research section

## License

This project is available for personal use.

## Credits

- Font Awesome for icons
- Google Fonts for typography
- Created based on the CV of Nura Dahiru Musa
